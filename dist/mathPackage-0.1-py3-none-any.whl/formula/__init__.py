import math


def area_of_circle():
    radius = int(input("Enter your radius : "))
    area_formula = math.pi * radius * radius
    print("Your radius is ", area_formula)

area_of_circle()